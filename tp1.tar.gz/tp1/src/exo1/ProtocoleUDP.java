package exo1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

public class ProtocoleUDP {
	
	public ProtocoleUDP() {}
		
	
	//http://www.liafa.jussieu.fr/~sighirea/cours/reseauxM/java.udp.html
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		byte[] buffer = new byte[15];
		buffer = "Message by Thibault".getBytes();
		
		InetSocketAddress adress = new InetSocketAddress("172.18.12.83", 7654);
		
		DatagramSocket socket = new DatagramSocket();
		//socket.connect(adress);
		
		DatagramPacket dataPacket = new DatagramPacket(buffer, buffer.length, adress);
		
		//socket.send(dataPacket);
		
		System.out.println(1);
		socket.receive(dataPacket);
		System.out.println(2);
		socket.close();
		
		System.out.println(dataPacket.getData());
		
	}

}
